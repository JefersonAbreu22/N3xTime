import { http } from './http';
import { TeamUser, normalizeTeamUser } from './usersApi';

export type Department = {
  id: number;
  name: string;
  users?: TeamUser[];
};

export const departmentsApi = {
  list: async () => {
    const res = await http.get<{ success: boolean; data: Department[] }>('/departments');
    return {
      ...res.data,
      data: res.data.data.map((department) => ({
        ...department,
        users: department.users?.map(normalizeTeamUser),
      })),
    };
  },
  create: async (name: string) => {
    const res = await http.post<{ success: boolean; data: Department }>('/departments', { name });
    return res.data;
  },
  update: async (id: number, name: string) => {
    const res = await http.put<{ success: boolean; data: Department }>(`/departments/${id}`, { name });
    return res.data;
  },
  delete: async (id: number) => {
    const res = await http.delete<{ success: boolean; message: string }>(`/departments/${id}`);
    return res.data;
  },
};

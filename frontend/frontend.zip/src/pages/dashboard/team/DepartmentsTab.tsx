import { useState } from 'react';
import { Building, Plus } from 'lucide-react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { departmentsApi } from '../../../services/departmentsApi';

export default function DepartmentsTab() {
  const queryClient = useQueryClient();
  const [isDeptModalOpen, setIsDeptModalOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<{ id: number; name: string } | null>(null);
  const [deptForm, setDeptForm] = useState({ name: '' });

  const depts = useQuery({
    queryKey: ['departments'],
    queryFn: async () => {
      const res = await departmentsApi.list();
      return res.data;
    },
  });

  const saveDept = useMutation({
    mutationFn: async () => {
      if (editingDept) {
        return departmentsApi.update(editingDept.id, deptForm.name);
      }
      return departmentsApi.create(deptForm.name);
    },
    onSuccess: async () => {
      toast.success(editingDept ? 'Setor atualizado.' : 'Setor criado.');
      setDeptForm({ name: '' });
      setEditingDept(null);
      setIsDeptModalOpen(false);
      await queryClient.invalidateQueries({ queryKey: ['departments'] });
    },
    onError: () => toast.error('Erro ao salvar setor.'),
  });

  const removeDept = useMutation({
    mutationFn: async (id: number) => {
      if (!confirm('Deseja realmente remover este setor?')) throw new Error('Cancelled');
      await departmentsApi.delete(id);
    },
    onSuccess: async () => {
      toast.success('Setor removido.');
      await queryClient.invalidateQueries({ queryKey: ['departments'] });
    },
    onError: (error: unknown) => {
      const err = error as { message: string; response?: { data?: { error?: string } } };
      if (err.message !== 'Cancelled') toast.error(err.response?.data?.error || 'Erro ao remover setor.');
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
        <div>
          <h2 className="text-2xl font-semibold tracking-[-0.04em] text-[#191717]">Setores</h2>
          <p className="mt-2 text-sm text-[#6e6a6a]">Gerencie a estrutura organizacional da empresa.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => {
              setEditingDept(null);
              setDeptForm({ name: '' });
              setIsDeptModalOpen(true);
            }}
            className="btn-primary"
          >
            <Plus className="h-4 w-4" />
            Novo Setor
          </button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {depts.isLoading ? (
          <div className="col-span-full py-12 text-center text-[#6e6a6a]">Carregando setores...</div>
        ) : depts.data?.length === 0 ? (
          <div className="col-span-full surface-panel py-16 text-center text-[#6e6a6a]">
            Nenhum setor cadastrado.
          </div>
        ) : (
          depts.data?.map((dept: { id: number; name: string; users?: unknown[] }) => (
            <div key={dept.id} className="surface-panel flex flex-col justify-between p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#f8f6f6]">
                    <Building className="h-5 w-5 text-[#026666]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#191717]">{dept.name}</h3>
                    <p className="text-sm text-[#6e6a6a]">
                      {dept.users?.length || 0} colaborador(es)
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-6 flex justify-end gap-2 border-t border-[#ece8e8] pt-4">
                <button
                  onClick={() => {
                    setEditingDept(dept);
                    setDeptForm({ name: dept.name });
                    setIsDeptModalOpen(true);
                  }}
                  className="btn-ghost"
                >
                  Editar
                </button>
                <button
                  onClick={() => removeDept.mutate(dept.id)}
                  className="btn-ghost text-red-600 hover:bg-red-50 hover:text-red-700"
                >
                  Excluir
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {isDeptModalOpen && (
        <div className="modal-shell">
          <div className="modal-card max-w-md overflow-hidden">
            <div className="flex items-center justify-between border-b border-[#ece8e8] bg-[#fcfbfb] px-6 py-5">
              <div>
                <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#026666]">Setores</div>
                <h3 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[#191717]">{editingDept ? 'Editar setor' : 'Novo setor'}</h3>
              </div>
              <button onClick={() => setIsDeptModalOpen(false)} className="btn-ghost">✕</button>
            </div>
            <div className="p-6">
              <div className="space-y-1.5">
                <label className="field-label">Nome do setor</label>
                <input className="field-input" placeholder="Ex: Tecnologia da Informação" value={deptForm.name} onChange={(e) => setDeptForm((state) => ({ ...state, name: e.target.value }))} />
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t border-[#ece8e8] bg-[#f8f6f6] px-6 py-4">
              <button onClick={() => setIsDeptModalOpen(false)} className="btn-secondary">Cancelar</button>
              <button
                onClick={() => saveDept.mutate()}
                disabled={saveDept.isPending || deptForm.name.trim().length < 3}
                className="btn-primary"
              >
                {saveDept.isPending ? 'Salvando...' : 'Salvar'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useAuthStore } from '../../stores/authStore';

export default function PermissionsPage() {
  const auth = useAuthStore();

  return (
    <div className="surface-panel p-6">
      <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#026666]">Politicas</div>
      <h3 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[#191717]">Funcoes e permissoes</h3>
      {auth.user?.role !== 'admin' ? (
        <div className="mt-4 text-sm text-[#6e6a6a]">Acesso restrito ao RH/Administrador.</div>
      ) : (
        <div className="mt-4 text-sm leading-7 text-[#6e6a6a]">
          Nenhuma regra personalizada cadastrada. As permissões atuais seguem os perfis fixos: admin, manager e employee.
        </div>
      )}
    </div>
  );
}

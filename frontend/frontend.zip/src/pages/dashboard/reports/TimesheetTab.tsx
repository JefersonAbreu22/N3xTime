import { useOutletContext } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { type ReportsContextType } from './ReportsLayout';
import { ReportSectionHeader, downloadHtmlAsExcel, exportTableToPdf } from './reportsHelpers';
import { formatMinutes, recordTypeLabel, requestStatusLabel, requestTypeLabel, todayKey, buildUploadUrl } from '../../../components/dashboard/dashboardUtils';
import { reportsApi } from '../../../services/reportsApi';

interface TimelineItem {
  id?: number | string;
  timeLabel?: string;
  recordTime: string | Date;
  recordType: 'entry' | 'lunch_start' | 'lunch_end' | 'exit';
  method?: 'facial' | 'pin' | 'manual' | 'web';
  mapUrl?: string;
  photoUrl?: string;
}

interface DayView {
  date?: string;
  timeline?: TimelineItem[];
  workedMinutes?: number;
  balanceMinutes?: number;
  status?: 'absent' | 'in_progress' | 'complete';
}

interface UserAttendance {
  userId: number;
  name: string;
  departmentName?: string;
  allDailyViews?: DayView[];
  bankHours?: {
    workedMinutesTotal: number;
    expectedMinutesTotal: number;
    balanceMinutesTotal: number;
    overtimeMinutes: number;
    deficitMinutes: number;
  };
}

export default function TimesheetTab() {
  const { filters, summaryData } = useOutletContext<ReportsContextType>();

  const parsedDepartmentId = filters.departmentId ? Number(filters.departmentId) : null;
  const parsedUserId = filters.userId ? Number(filters.userId) : null;

  const attendanceQuery = useQuery({
    queryKey: ['reports', 'timesheet', filters.startDate, filters.endDate, parsedDepartmentId, parsedUserId],
    queryFn: async () =>
      reportsApi.attendance({
        startDate: filters.startDate,
        endDate: filters.endDate,
        departmentId: parsedDepartmentId,
        userId: parsedUserId,
      }),
  });

  const attendanceData = attendanceQuery.data?.data ?? [];
  const selectedAttendanceUser = parsedUserId && attendanceData.length === 1 ? attendanceData[0] as UserAttendance : null;
  const occurrencesByDate = new Map<string, { requestType: string; status: string }>();
  for (const occurrence of summaryData?.absenceDocuments ?? []) {
    const occurrenceUserId = Number((occurrence as unknown as { userId?: number }).userId);
    if (selectedAttendanceUser && occurrenceUserId === selectedAttendanceUser.userId && occurrence.targetDate && !occurrencesByDate.has(occurrence.targetDate)) {
      occurrencesByDate.set(occurrence.targetDate, { requestType: occurrence.requestType, status: occurrence.status });
    }
  }

  const getDayStatus = (dayView: DayView) => {
    const occurrence = dayView.date ? occurrencesByDate.get(dayView.date) : undefined;
    if (occurrence) return `${requestTypeLabel(occurrence.requestType)} — ${requestStatusLabel(occurrence.status)}`;
    if (dayView.status === 'complete') return 'Jornada completa';
    if (dayView.status === 'in_progress') return 'Jornada em andamento';
    return 'Sem marcação';
  };

  const getRecordTime = (dayView: DayView, recordType: TimelineItem['recordType']) =>
    dayView.timeline?.find((item) => item.recordType === recordType)?.timeLabel ?? '—';

  const handleExportIndividualPdf = () => {
    if (!selectedAttendanceUser?.allDailyViews) return;
    exportTableToPdf({
      title: `Espelho de Ponto: ${selectedAttendanceUser.name}`,
      subtitle: `Período ${filters.startDate} até ${filters.endDate} | Setor: ${selectedAttendanceUser.departmentName ?? 'Não informado'}`,
      fileName: `espelho-${selectedAttendanceUser.name.toLowerCase().replace(/\s+/g, '-')}-${filters.startDate}-${filters.endDate}.pdf`,
      columns: ['Data', 'Entrada', 'Saída almoço', 'Retorno', 'Saída', 'Jornada', 'Saldo', 'Status / ocorrência', 'Origem'],
      rows: selectedAttendanceUser.allDailyViews.map((dayView) => {
        const remote = dayView.timeline?.some((item) => item.method === 'web');
        return [
          dayView.date ?? '—',
          getRecordTime(dayView, 'entry'),
          getRecordTime(dayView, 'lunch_start'),
          getRecordTime(dayView, 'lunch_end'),
          getRecordTime(dayView, 'exit'),
          formatMinutes(dayView.workedMinutes ?? 0),
          formatMinutes(dayView.balanceMinutes ?? 0),
          getDayStatus(dayView),
          remote ? 'Ponto remoto' : dayView.timeline?.length ? 'Terminal / manual' : '—',
        ];
      }),
      signature: { collaboratorName: selectedAttendanceUser.name },
    });
  };

  const handleExportExcel = () => {
    downloadHtmlAsExcel({
      title: `Espelho Diario da Equipe`,
      subtitle: `Periodo: ${filters.startDate} a ${filters.endDate}`,
      fileName: `espelho-diario-equipe-${todayKey()}.xls`,
      columns: ['Colaborador', 'Data', 'Entrada', 'Saida Almoco', 'Retorno Almoco', 'Saida', 'Jornada Realizada', 'Saldo'],
      rows: (() => {
        if (!attendanceData) return [];
        const rowsToExport: Array<Array<string>> = [];
        (attendanceData as UserAttendance[]).forEach((userAttendance) => {
          if (userAttendance.allDailyViews) {
            userAttendance.allDailyViews.forEach((dayView, idx) => {
              const dateKey = dayView.date || `Dia ${idx + 1}`;
              let entry = '—', lunch_start = '—', lunch_end = '—', exit = '—';
              if (dayView.timeline) {
                dayView.timeline.forEach((item) => {
                  const time = item.timeLabel || new Date(item.recordTime).toLocaleTimeString();
                  if (item.recordType === 'entry') entry = time;
                  else if (item.recordType === 'lunch_start') lunch_start = time;
                  else if (item.recordType === 'lunch_end') lunch_end = time;
                  else if (item.recordType === 'exit') exit = time;
                });
              }
              const worked = formatMinutes(dayView.workedMinutes ?? 0);
              const balance = dayView.balanceMinutes ? (dayView.balanceMinutes > 0 ? `+${formatMinutes(dayView.balanceMinutes)}` : `-${formatMinutes(Math.abs(dayView.balanceMinutes))}`) : '0h 00m';
              rowsToExport.push([userAttendance.name, dateKey, entry, lunch_start, lunch_end, exit, worked, balance]);
            });
          }
        });
        return rowsToExport;
      })(),
    });
  };

  return (
    <div className="space-y-6">
      <section id="daily-sheet" className="surface-panel p-5">
        <ReportSectionHeader
          eyebrow="Espelho diario consolidado"
          title="Visão em tabela de equipe"
          note="Consulte rapidamente todas as marcações da equipe no período filtrado. Use para auditoria rápida de horários."
          aside={
            <div className="flex flex-wrap items-end gap-3">
              <button 
                type="button" 
                className="btn-secondary" 
                onClick={handleExportExcel} 
                disabled={!attendanceData || attendanceData.length === 0}
              >
                Exportar Excel
              </button>
              <button
                type="button"
                className="btn-primary"
                onClick={handleExportIndividualPdf}
                disabled={!selectedAttendanceUser}
                title={selectedAttendanceUser ? 'Gera o espelho individual com campo de assinatura' : 'Selecione um colaborador no filtro geral'}
              >
                PDF individual com assinatura
              </button>
            </div>
          }
        />

        {!selectedAttendanceUser && (
          <div className="mt-5 border border-[#ece8e8] bg-[#f8f6f6] p-4 text-sm leading-6 text-[#6e6a6a]">
            Selecione um colaborador no filtro geral para gerar o espelho individual completo, incluindo folgas, férias, atestados e trabalho externo.
          </div>
        )}

        {parsedUserId && attendanceData.length === 1 && (
          <div className="grid gap-3 md:grid-cols-4 mt-5">
            <div className="insight-card">
              <div className="metric-label">Total Trabalhado</div>
              <div className="mt-2 text-xl font-bold text-[#191717]">{formatMinutes((attendanceData[0] as UserAttendance).bankHours?.workedMinutesTotal ?? 0)}</div>
            </div>
            <div className="insight-card">
              <div className="metric-label">Carga Exigida</div>
              <div className="mt-2 text-xl font-bold text-[#191717]">{formatMinutes((attendanceData[0] as UserAttendance).bankHours?.expectedMinutesTotal ?? 0)}</div>
            </div>
            <div className="insight-card">
              <div className="metric-label">Saldo do Período</div>
              <div className={`mt-2 text-xl font-bold ${((attendanceData[0] as UserAttendance).bankHours?.balanceMinutesTotal ?? 0) > 0 ? 'text-[#026666]' : ((attendanceData[0] as UserAttendance).bankHours?.balanceMinutesTotal ?? 0) < 0 ? 'text-[#b43737]' : 'text-[#191717]'}`}>
                {((attendanceData[0] as UserAttendance).bankHours?.balanceMinutesTotal ?? 0) > 0 ? '+' : ''}{formatMinutes((attendanceData[0] as UserAttendance).bankHours?.balanceMinutesTotal ?? 0)}
              </div>
            </div>
            <div className="insight-card flex gap-4">
              <div className="flex-1">
                <div className="metric-label">Horas Extras</div>
                <div className="mt-1 text-lg font-bold text-[#026666]">{formatMinutes((attendanceData[0] as UserAttendance).bankHours?.overtimeMinutes ?? 0)}</div>
              </div>
              <div className="w-px bg-[#ebe8e8]"></div>
              <div className="flex-1">
                <div className="metric-label">Déficit / Atrasos</div>
                <div className="mt-1 text-lg font-bold text-[#b43737]">{formatMinutes((attendanceData[0] as UserAttendance).bankHours?.deficitMinutes ?? 0)}</div>
              </div>
            </div>
          </div>
        )}

        <div className="overflow-x-auto border border-[#ebe8e8] rounded-xl mt-5">
          <table className="data-table min-w-[800px]">
            <thead>
              <tr>
                <th>Colaborador</th>
                <th>Data</th>
                <th>Entrada</th>
                <th>Saída Almoço</th>
                <th>Retorno Almoço</th>
                <th>Saída</th>
                <th>Jornada</th>
                <th>Saldo</th>
                <th>Status / ocorrência</th>
                <th>Evidências</th>
              </tr>
            </thead>
            <tbody>
              {(() => {
                if (!attendanceData || attendanceData.length === 0) {
                  return (
                    <tr>
                      <td colSpan={10} className="py-8 text-center text-[#6e6a6a]">Sem marcações na equipe para este período.</td>
                    </tr>
                  );
                }
                
                const rowsToRender: React.ReactNode[] = [];
                (attendanceData as UserAttendance[]).forEach((userAttendance) => {
                  if (userAttendance.allDailyViews && userAttendance.allDailyViews.length > 0) {
                    userAttendance.allDailyViews.forEach((dayView, idx) => {
                      const dateKey = dayView.date || `Dia ${idx + 1}`;
                      let entry: TimelineItem | null = null, lunch_start: TimelineItem | null = null, lunch_end: TimelineItem | null = null, exit: TimelineItem | null = null;
                      
                      if (dayView.timeline) {
                        dayView.timeline.forEach((item) => {
                          if (item.recordType === 'entry') entry = item;
                          else if (item.recordType === 'lunch_start') lunch_start = item;
                          else if (item.recordType === 'lunch_end') lunch_end = item;
                          else if (item.recordType === 'exit') exit = item;
                        });
                      }

                      const renderRecordCell = (record: TimelineItem | null) => {
                        if (!record) return <span className="text-[#6e6a6a]">—</span>;
                        const time = record.timeLabel || new Date(record.recordTime).toLocaleTimeString();
                        return (
                          <div className="flex flex-col gap-1">
                            <span className="font-semibold text-[#191717]">{time}</span>
                            {(record.mapUrl || record.photoUrl) && (
                              <div className="flex flex-col gap-0.5 text-[11px]">
                                {record.mapUrl && <a className="font-medium text-[#026666] hover:underline" href={record.mapUrl} target="_blank" rel="noreferrer">Mapa</a>}
                                {record.photoUrl && (
                                  <a href={buildUploadUrl(record.photoUrl) || undefined} target="_blank" rel="noreferrer" className="block mt-0.5" title="Ver foto">
                                    <img src={buildUploadUrl(record.photoUrl) || undefined} alt="Selfie" className="w-8 h-8 rounded-md object-cover border border-[#ece8e8]" />
                                  </a>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      };

                      const renderEvidenceCell = (records: Array<TimelineItem | null>) => {
                        const evidenceRecords = records.filter((record): record is TimelineItem => Boolean(record && (record.mapUrl || record.photoUrl)));
                        if (!evidenceRecords.length) return <span className="text-[#6e6a6a]">—</span>;
                        return (
                          <div className="flex flex-col gap-1 text-[11px]">
                            {evidenceRecords.map((record) => (
                              <div key={`team-evidence-${record.id || Math.random()}`} className="flex flex-wrap gap-1.5 items-center">
                                <span className="font-medium text-[#191717] uppercase tracking-wider">{recordTypeLabel(record.recordType)}:</span>
                                {record.mapUrl ? <a className="font-medium text-[#026666] hover:underline" href={record.mapUrl} target="_blank" rel="noreferrer">Mapa</a> : null}
                                {record.photoUrl ? (
                                  <a href={buildUploadUrl(record.photoUrl) || undefined} target="_blank" rel="noreferrer" title="Ver foto">
                                    <img src={buildUploadUrl(record.photoUrl) || undefined} alt="Selfie" className="w-8 h-8 rounded-md object-cover border border-[#ece8e8]" />
                                  </a>
                                ) : null}
                              </div>
                            ))}
                          </div>
                        );
                      };
                      
                      rowsToRender.push(
                        <tr key={`${userAttendance.userId}-${idx}`} className="hover:bg-[#fcfbfb]">
                          <td className="font-medium text-[#191717]">{userAttendance.name}</td>
                          <td className="font-medium text-[#191717] whitespace-nowrap">{dateKey}</td>
                          <td>{renderRecordCell(entry)}</td>
                          <td>{renderRecordCell(lunch_start)}</td>
                          <td>{renderRecordCell(lunch_end)}</td>
                          <td>{renderRecordCell(exit)}</td>
                          <td>
                            <div className="font-medium text-[#026666]">
                              {formatMinutes(dayView.workedMinutes ?? 0)}
                            </div>
                          </td>
                          <td>
                            {(dayView.balanceMinutes ?? 0) > 0 ? (
                              <span className="text-[#026666] font-medium">+{formatMinutes(dayView.balanceMinutes ?? 0)}</span>
                            ) : (dayView.balanceMinutes ?? 0) < 0 ? (
                              <span className="text-[#b43737] font-medium">{formatMinutes(Math.abs(dayView.balanceMinutes ?? 0))}</span>
                            ) : (
                              <span className="text-[#6e6a6a]">—</span>
                            )}
                          </td>
                          <td>
                            <span className="text-sm font-medium text-[#191717]">{getDayStatus(dayView)}</span>
                          </td>
                          <td>{renderEvidenceCell([entry, lunch_start, lunch_end, exit])}</td>
                        </tr>
                      );
                    });
                  }
                });
                return rowsToRender;
              })()}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

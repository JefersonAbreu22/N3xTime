import { Clock3, MapPinned, TimerReset } from 'lucide-react';
import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { useAuthStore } from '../../stores/authStore';
import { recordsApi } from '../../services/recordsApi';
import { reportsApi } from '../../services/reportsApi';
import {
  formatMinutes,
  methodLabel,
  monthStartKey,
  recordTypeLabel,
  todayKey,
  buildUploadUrl,
} from '../../components/dashboard/dashboardUtils';
import RequestAdjustmentModal from '../../components/dashboard/RequestAdjustmentModal';
import RemoteClockInModal from '../../components/dashboard/RemoteClockInModal';

export default function MyRecordsPage() {
  const auth = useAuthStore();
  const queryClient = useQueryClient();
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [isRemoteModalOpen, setIsRemoteModalOpen] = useState(false);

  const my = useQuery({
    queryKey: ['records', 'me'],
    queryFn: async () => {
      const res = await recordsApi.myRecords();
      return res.data;
    },
    enabled: !!auth.token,
  });

  const hrSummary = useQuery({
    queryKey: ['my-point', 'summary', todayKey()],
    queryFn: async () => reportsApi.hrSummary({ startDate: monthStartKey(), endDate: todayKey() }),
    enabled: !!auth.token,
  });

  const summary = hrSummary.data?.data?.bankHours;
  const latestRecord = my.data?.[0];
  const latestDailyBalance = summary?.latestDailyBalance;

  // Organiza os saldos diários do mais recente para o mais antigo
  const dailyBalances = summary?.dailyBalances ? [...summary.dailyBalances].reverse() : [];

  return (
    <div className="space-y-6">
      <section className="page-hero">
        <div className="page-hero-grid">
          <div className="border-b border-[#e7e4e4] p-5 md:p-6 xl:border-b-0 xl:border-r">
            <div className="page-eyebrow">Meu ponto</div>
            <h2 className="page-title">Histórico, marcações e evidências</h2>
            <p className="page-description">
              Consulte sua jornada consolidada, acompanhe o último registro realizado e acesse as evidências do ponto remoto.
            </p>
          </div>
          <div className="p-5 md:p-6">
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#6e6a6a]">Ações rápidas</div>
            <div className="mt-4 flex flex-wrap gap-3">
              {auth.user?.remote_clock_in_enabled && (
                <button 
                  onClick={() => setIsRemoteModalOpen(true)} 
                  className="btn-primary flex items-center gap-2 bg-[#026666] hover:bg-[#014d4d]"
                >
                  Registrar Ponto
                </button>
              )}
              <button onClick={() => setIsRequestModalOpen(true)} className="btn-secondary">
                Solicitar Ajuste
              </button>
              <Link to="/dashboard/requests" className="btn-ghost">
                Ir para Solicitações
              </Link>
            </div>
            <div className="mt-6 text-sm leading-6 text-[#6e6a6a]">
              Último evento: {latestRecord ? `${recordTypeLabel(latestRecord.record_type)} em ${new Date(latestRecord.record_time).toLocaleString()}` : 'nenhuma marcação recente.'}
            </div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div className="metric-label">Horas Hoje</div>
            <Clock3 className="h-5 w-5 text-[#026666]" />
          </div>
          <div className="metric-value">{formatMinutes(latestDailyBalance?.workedMinutes ?? 0)}</div>
          <div className="mt-2 text-sm text-[#6e6a6a]">Trabalhadas na data mais recente consolidada.</div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div className="metric-label">Saldo Banco</div>
            <TimerReset className="h-5 w-5 text-[#026666]" />
          </div>
          <div className="metric-value">{formatMinutes(summary?.balanceMinutesTotal ?? 0)}</div>
          <div className="mt-2 text-sm text-[#6e6a6a]">Saldo acumulado no período atual.</div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div className="metric-label">Última Marcação</div>
            <Clock3 className="h-5 w-5 text-[#026666]" />
          </div>
          <div className="metric-value text-[1.35rem] md:text-[1.6rem]">
            {latestRecord ? recordTypeLabel(latestRecord.record_type) : 'Sem registro'}
          </div>
          <div className="mt-2 text-sm text-[#6e6a6a]">
            {latestRecord ? new Date(latestRecord.record_time).toLocaleString() : 'Nenhuma movimentação encontrada.'}
          </div>
        </div>
        <div className="metric-card">
          <div className="flex items-center justify-between">
            <div className="metric-label">Evidências</div>
            <MapPinned className="h-5 w-5 text-[#026666]" />
          </div>
          <div className="metric-value">
            {(my.data ?? []).filter((record) => record.map_url || record.photo_url).length}
          </div>
          <div className="mt-2 text-sm text-[#6e6a6a]">Marcações com mapa ou foto registrada.</div>
        </div>
      </section>

      <div className="surface-panel p-6">
        <div className="flex flex-col gap-3 border-b border-[#ece8e8] pb-5 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#026666]">Resumo diário</div>
            <h3 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[#191717]">Espelho de Ponto</h3>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="text-sm text-[#6e6a6a]">Acompanhe seu saldo, entradas, saídas e horas extras por dia.</div>
          </div>
        </div>

        <div className="mt-6 overflow-x-auto border border-[#ebe8e8] rounded-xl">
          <table className="data-table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Entrada</th>
                <th>Saída</th>
                <th>Jornada Realizada</th>
                <th>Faltam (Déficit)</th>
                <th>Horas Extras</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {dailyBalances.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#6e6a6a]">Nenhum resumo disponível para este mês.</td>
                </tr>
              ) : (
                dailyBalances.map((day) => (
                  <tr key={day.date}>
                    <td>
                      <div className="font-medium text-[#191717]">
                        {new Date(`${day.date}T12:00:00`).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                      </div>
                      <div className="text-xs text-[#6e6a6a]">
                        {new Date(`${day.date}T12:00:00`).toLocaleDateString('pt-BR', { weekday: 'short' })}
                      </div>
                    </td>
                    <td>{day.entryTime || '—'}</td>
                    <td>{day.exitTime || '—'}</td>
                    <td>
                      <div className="font-medium text-[#026666]">
                        {formatMinutes(day.workedMinutes)}
                      </div>
                      {day.expectedMinutes > 0 && (
                        <div className="text-xs text-[#6e6a6a]">
                          Previsto: {formatMinutes(day.expectedMinutes)}
                        </div>
                      )}
                    </td>
                    <td>
                      {day.isAbsence ? (
                        <span className="text-[#b43737] font-medium">Falta integral</span>
                      ) : day.balanceMinutes < 0 ? (
                        <span className="text-[#b43737] font-medium">{formatMinutes(Math.abs(day.balanceMinutes))}</span>
                      ) : (
                        <span className="text-[#6e6a6a]">—</span>
                      )}
                    </td>
                    <td>
                      {day.balanceMinutes > 0 ? (
                        <span className="text-[#026666] font-medium">+{formatMinutes(day.balanceMinutes)}</span>
                      ) : (
                        <span className="text-[#6e6a6a]">—</span>
                      )}
                    </td>
                    <td>
                      {day.isHoliday ? (
                        <span className="status-chip bg-[#eef2fa] text-[#2d5299] border-[#d9e2f2]">Feriado</span>
                      ) : day.isJustifiedAbsence ? (
                        <span className="status-chip bg-[#f4f8f8] text-[#026666] border-[#dceaea]">Justificado</span>
                      ) : day.isAbsence ? (
                        <span className="status-chip bg-[#fdf3f3] text-[#b43737] border-[#f8e1e1]">Ausente</span>
                      ) : day.hasCompleteJourney ? (
                        <span className="status-chip bg-[#f4f8f8] text-[#026666] border-[#dceaea]">Completo</span>
                      ) : day.workedMinutes > 0 ? (
                        <span className="status-chip bg-[#fff8e6] text-[#b36b00] border-[#fde8b3]">Incompleto</span>
                      ) : (
                        <span className="text-[#6e6a6a]">—</span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="surface-panel p-6">
        <div className="flex flex-col gap-3 border-b border-[#ece8e8] pb-5 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="text-xs font-semibold uppercase tracking-[0.18em] text-[#026666]">Histórico operacional</div>
            <h3 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-[#191717]">Lista de Marcações Brutas</h3>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="text-sm text-[#6e6a6a]">Consulte as batidas individuais, métodos, geolocalização e foto do histórico.</div>
          </div>
        </div>

        <div className="mt-6">
          {!auth.token ? (
          <div className="py-16 text-center text-[#6e6a6a]">Faça login para visualizar seus registros.</div>
        ) : my.isLoading ? (
          <div className="py-16 text-center text-[#6e6a6a]">Carregando historico...</div>
        ) : (my.data?.length ?? 0) === 0 ? (
          <div className="py-16 text-center text-[#6e6a6a]">Nenhum registro encontrado.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Data/Hora</th>
                  <th>Tipo</th>
                  <th>Metodo</th>
                  <th>Status</th>
                  <th>Geo</th>
                  <th>Dispositivo</th>
                </tr>
              </thead>
              <tbody>
                {my.data?.map((record) => (
                  <tr key={record.id}>
                    <td>{new Date(record.record_time).toLocaleString()}</td>
                    <td>
                      <span className="status-chip border-[#dceaea] bg-[#edf8f8] text-[#026666]">
                        {recordTypeLabel(record.record_type)}
                      </span>
                    </td>
                    <td>{methodLabel(record.method)}</td>
                    <td>{record.status}</td>
                    <td>
                      <div className="flex flex-col gap-1">
                        {record.map_url ? (
                          <a className="font-semibold text-[#026666] hover:underline" href={record.map_url} target="_blank" rel="noreferrer">
                            Abrir no Google Maps
                          </a>
                        ) : (
                          <span>—</span>
                        )}
                        {record.photo_url ? (
                          <a
                            href={buildUploadUrl(record.photo_url) || undefined}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-1 block overflow-hidden rounded-md border border-[#ece8e8] w-12 h-12 hover:opacity-80 transition-opacity shrink-0"
                            title="Ver foto capturada"
                          >
                            <img src={buildUploadUrl(record.photo_url) || undefined} alt="Selfie" className="w-full h-full object-cover" />
                          </a>
                        ) : null}
                      </div>
                    </td>
                    <td className="max-w-[220px] truncate">{record.device_info || '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        </div>
      </div>

      {isRequestModalOpen && (
        <RequestAdjustmentModal
          onClose={() => setIsRequestModalOpen(false)}
          onSuccess={() => {
            setIsRequestModalOpen(false);
            queryClient.invalidateQueries({ queryKey: ['records', 'me'] });
            queryClient.invalidateQueries({ queryKey: ['requests', 'my'] });
            queryClient.invalidateQueries({ queryKey: ['my-point', 'summary'] });
            toast.success('Solicitação enviada com sucesso!');
          }}
          myRecords={my.data || []}
        />
      )}

      <RemoteClockInModal
        isOpen={isRemoteModalOpen}
        onClose={() => setIsRemoteModalOpen(false)}
      />
    </div>
  );
}

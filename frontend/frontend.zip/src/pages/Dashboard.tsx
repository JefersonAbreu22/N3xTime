import { Suspense, lazy, useMemo } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../stores/authStore';
import DashboardSidebar from '../components/dashboard/DashboardSidebar';
import DashboardHeader from '../components/dashboard/DashboardHeader';
import MobileBottomNav from '../components/dashboard/MobileBottomNav';
import {
  getCurrentDashboardPageTitle,
  getDashboardNavSections,
  getDashboardProfileLabel,
  getDisplayInitials,
  getMobileNavItems,
} from '../components/dashboard/dashboardNavigation';

const OverviewPage = lazy(() => import('./dashboard/OverviewPage'));
const MyRecordsPage = lazy(() => import('./dashboard/MyRecordsPage'));
const MyRequestsPage = lazy(() => import('./dashboard/MyRequestsPage'));
const PendingPage = lazy(() => import('./dashboard/PendingPage'));
const TeamPage = lazy(() => import('./dashboard/team/TeamLayout'));
const EmployeesTab = lazy(() => import('./dashboard/team/EmployeesTab'));
const DepartmentsTab = lazy(() => import('./dashboard/team/DepartmentsTab'));
const SchedulesTab = lazy(() => import('./dashboard/team/SchedulesTab'));
const BiometricsTab = lazy(() => import('./dashboard/team/BiometricsTab'));
const ReportsLayout = lazy(() => import('./dashboard/reports/ReportsLayout'));
const IndicatorsTab = lazy(() => import('./dashboard/reports/IndicatorsTab'));
const TimesheetTab = lazy(() => import('./dashboard/reports/TimesheetTab'));
const DailyReportsTab = lazy(() => import('./dashboard/reports/DailyReportsTab'));
const RequestsTab = lazy(() => import('./dashboard/reports/RequestsTab'));
const ComplianceTab = lazy(() => import('./dashboard/reports/ComplianceTab'));
const ClosingTab = lazy(() => import('./dashboard/reports/ClosingTab'));
const SettingsPage = lazy(() => import('./dashboard/SettingsPage'));
const PermissionsPage = lazy(() => import('./dashboard/PermissionsPage'));

export default function Dashboard() {
  const location = useLocation();
  const navigate = useNavigate();
  const auth = useAuthStore();
  const role = auth.user?.role ?? 'employee';

  const navSections = useMemo(() => getDashboardNavSections(role), [role]);

  const handleLogout = () => {
    auth.clearSession();
    navigate('/login');
  };

  const currentPageTitle = useMemo(() => getCurrentDashboardPageTitle(location.pathname), [location.pathname]);
  const mobileNavItems = useMemo(() => getMobileNavItems(role), [role]);
  const profileLabel = useMemo(() => getDashboardProfileLabel(role), [role]);
  const displayInitials = auth.user ? getDisplayInitials(auth.user.name) : '';

  return (
    <div className="app-shell flex h-screen overflow-hidden">
      <DashboardSidebar navSections={navSections} pathname={location.pathname} user={auth.user} onLogout={handleLogout} />

      <div className="flex min-w-0 flex-1 flex-col">
        <DashboardHeader
          currentPageTitle={currentPageTitle}
          profileLabel={profileLabel}
          user={auth.user ? { name: auth.user.name, role: auth.user.role } : null}
          displayInitials={displayInitials}
          onLogin={() => navigate('/login')}
        />

        <main className="min-h-0 flex-1 overflow-y-auto p-4 pb-24 md:p-5 md:pb-24 xl:p-6 xl:pb-6">
          <Suspense fallback={<div className="surface-panel py-16 text-center text-[#6e6a6a]">Carregando página...</div>}>
            <Routes>
              <Route path="/" element={<OverviewPage />} />
              <Route path="/my-point" element={<MyRecordsPage />} />
              <Route path="/records" element={<Navigate to="/dashboard/my-point" replace />} />
              <Route path="/requests" element={<MyRequestsPage />} />
              <Route path="/pending" element={<PendingPage />} />
              <Route path="/team" element={<TeamPage />}>
                <Route index element={<Navigate to="employees" replace />} />
                <Route path="employees" element={<EmployeesTab />} />
                <Route path="departments" element={<DepartmentsTab />} />
                <Route path="schedules" element={<SchedulesTab />} />
                <Route path="biometrics" element={<BiometricsTab />} />
              </Route>
              <Route path="/reports" element={<ReportsLayout />}>
                <Route index element={<Navigate to="indicators" replace />} />
                <Route path="indicators" element={<IndicatorsTab />} />
                <Route path="timesheet" element={<TimesheetTab />} />
                <Route path="daily" element={<DailyReportsTab />} />
                <Route path="requests" element={<RequestsTab />} />
                <Route path="compliance" element={<ComplianceTab />} />
                <Route path="closing" element={<ClosingTab />} />
              </Route>
              <Route path="/settings" element={role === 'admin' ? <SettingsPage /> : <Navigate to="/dashboard" replace />} />
              <Route path="/settings/permissions" element={role === 'admin' ? <PermissionsPage /> : <Navigate to="/dashboard" replace />} />
            </Routes>
          </Suspense>
        </main>
      </div>

      <MobileBottomNav items={mobileNavItems} pathname={location.pathname} />
    </div>
  );
}

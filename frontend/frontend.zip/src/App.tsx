import { Suspense, lazy, type ReactElement } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useAuthStore } from './stores/authStore';
import ChunkLoadRecovery from './components/ChunkLoadRecovery';

const Kiosk = lazy(() => import('./pages/Kiosk'));
const Dashboard = lazy(() => import('./pages/Dashboard'));
const Login = lazy(() => import('./pages/Login'));

function ProtectedRoute({ children }: { children: ReactElement }) {
  const token = useAuthStore((state) => state.token);
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function App() {
  return (
    <BrowserRouter>
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            borderRadius: '10px',
            border: '1px solid #d9d7d7',
            background: '#fcfbfb',
            color: '#191717',
            fontFamily: 'Poppins, sans-serif',
            boxShadow: '0 18px 50px rgba(25, 23, 23, 0.12)',
          },
        }}
      />
      <ChunkLoadRecovery>
        <Suspense
          fallback={
            <div className="flex min-h-screen items-center justify-center bg-[#f6f4f4] px-6 text-center text-sm text-[#6e6a6a]">
              Carregando ambiente...
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<Navigate to="/login" replace />} />
            <Route path="/kiosk" element={<Kiosk />} />
            <Route path="/login" element={<Login />} />
            <Route
              path="/dashboard/*"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
          </Routes>
        </Suspense>
      </ChunkLoadRecovery>
    </BrowserRouter>
  );
}

export default App;

import { create } from 'zustand';

type AuthUser = {
  id: number;
  name: string;
  email: string;
  role: 'admin' | 'manager' | 'employee';
  remote_clock_in_enabled?: boolean;
};

type AuthState = {
  token: string | null;
  user: AuthUser | null;
  setSession: (token: string, user: AuthUser) => void;
  clearSession: () => void;
};

const STORAGE_KEY = 'ponto-smart:session';

const loadInitial = (): Pick<AuthState, 'token' | 'user'> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { token: null, user: null };
    const parsed = JSON.parse(raw) as { token: string; user: AuthUser };
    if (!parsed?.token || !parsed?.user) return { token: null, user: null };
    return { token: parsed.token, user: parsed.user };
  } catch {
    return { token: null, user: null };
  }
};

export const useAuthStore = create<AuthState>((set) => ({
  ...loadInitial(),
  setSession: (token, user) =>
    set(() => {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ token, user }));
      return { token, user };
    }),
  clearSession: () =>
    set(() => {
      localStorage.removeItem(STORAGE_KEY);
      return { token: null, user: null };
    }),
}));

